﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI2.Contracts.Response;


using WEBAPI2.Models;

namespace WEBAPI2.Repository.Contract.Request

{
    public interface IUsers
    {
        Users SignIn(SignInModel model);
        Users SignUp(SignUpModel model);
    }
}
