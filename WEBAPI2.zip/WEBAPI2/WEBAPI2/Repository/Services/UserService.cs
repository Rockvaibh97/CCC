﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using WEBAPI2.Contracts.Response;
using WEBAPI2.Models;
using WEBAPI2.Repository.Contract.Request;

namespace WEBAPI2.Repository.Contract
{
    public class UserService:IUsers
    {
        private readonly ApplicationDbContext dbContext;

        public UserService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public Users SignIn(SignInModel model)
        {
            var user=dbContext.Users.SingleOrDefault(e => e.Email == model.Email && e.Password == model.Password);
            if(user!=null)
            {
                return user;
            }
            else
            {
                return null;
            }
        }

        public Users SignUp(SignUpModel model)
        {
            var user = new Users()
            {
                Name = model.Name,
                Email = model.Email,
                Password = model.Password,
                Gender = model.Gender
            };
            dbContext.Users.Add(user);
            dbContext.SaveChanges();
            return user;
        }
    }
}
