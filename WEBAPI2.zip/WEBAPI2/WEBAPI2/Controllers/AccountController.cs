﻿using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.IdentityModel.Tokens;
using System;
using System.Collections.Generic;
using System.IdentityModel.Tokens.Jwt;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using WEBAPI2.Contracts.Response;
using WEBAPI2.Repository.Contract.Request;

namespace WEBAPI2.Controllers
{
    [Route("api/[controller]")]
    [ApiController]

    public class AccountController : ControllerBase
    {
        private IUsers UserService;

        public AccountController(IUsers users, IConfiguration config)  
        {
            UserService = users;
            _config = config;
        }

        private IConfiguration _config { get; }

        [HttpPost]
        [Route("SignIn")]
        public IActionResult SignIn(SignInModel model)
        {
            if (model != null)
            {
                var user = UserService.SignIn(model);
                var ApiResponse = new ApiResponse();
                if (user == null)
                {
                    //not failure
                    ApiResponse.Ok = false;
                    ApiResponse.Status = 400;
                    ApiResponse.Message = "Invalid Login credentials !";
                    return Ok(ApiResponse);

                }
                else
                {
                    //success login

                    string token = GenerateJSONWebToken();
                    ApiResponse.Ok = true;
                    ApiResponse.Status = 200;
                    ApiResponse.Message = "Login success !";
                    ApiResponse.Data = user;
                    ApiResponse.Token =token;
                    return Ok(ApiResponse);
                }
            }
            else
            {
                return BadRequest();
            }

        }
        [HttpPost]
        [Route("SignUp")]
        public IActionResult SignUp(SignUpModel model)
        {
            if (model != null)
            {
                string token = GenerateJSONWebToken();
                var user = UserService.SignUp(model);
                var ApiResponse = new ApiResponse();
                ApiResponse.Ok = true;
                ApiResponse.Status = 200;
                ApiResponse.Message = "Login success";
                ApiResponse.Data = user;
                ApiResponse.Token = token;
                return Ok(ApiResponse);
            }
            else
            {
                return BadRequest();
            }
        }

        private string GenerateJSONWebToken()
        {
            var securityKey = new SymmetricSecurityKey(Encoding.UTF8.GetBytes(_config["Logging:Jwt:Key"]));
            var credentials = new SigningCredentials(securityKey, SecurityAlgorithms.HmacSha256);
            var token = new JwtSecurityToken(_config["Jwt:Issuer"],
              _config["Jwt:Issuer"],
              null,
              expires: DateTime.Now.AddMinutes(120),
              signingCredentials: credentials);
              return new JwtSecurityTokenHandler().WriteToken(token);
        }
    }
}
    

