﻿select*from employees
