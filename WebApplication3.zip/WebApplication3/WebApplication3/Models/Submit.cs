﻿using System;
using System.Collections.Generic;
using System.ComponentModel.DataAnnotations;
using System.Linq;
using System.Threading.Tasks;

namespace WebApplication3.Models
{
    public class Submit
    {
        [Key]
        public int Id { get; set; }
        public Country countrydetails { get; set; }
        public State statedetails { get; set; }
        public City citydetails { get; set; }

    }
}
