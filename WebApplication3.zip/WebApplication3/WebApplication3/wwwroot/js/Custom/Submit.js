﻿////$(document).ready(function () {
////    $("#SubmitContent").click(function () { 
////    var DdlSubmit = {};
////    if (($('#country').val() != 'Select' && $('#State').val() != 'Select'))
////    {
////        DdlSubmit.Idcity = $('#country option:selected').val();
////        DdlSubmit.IdState = $('#State option:selected').val();
////        DdlSubmit.IdCountry = $('#City option:selected').val();
////    }
////    $.ajax({
////        url: '/Home/Created',
////        type: 'POST',
////        dataType: 'json',
////        data: DdlSubmit,
////        async: false,
////        success: function (submit) {
////            if (submit.status == 'Success') {
////                alert("Success");
////            }                    
////        },

////        error: function () {
////            alert("Some error occurred");
////        }

////    });
////    });

////});