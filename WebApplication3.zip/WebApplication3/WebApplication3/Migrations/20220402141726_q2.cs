﻿using Microsoft.EntityFrameworkCore.Migrations;

namespace WebApplication3.Migrations
{
    public partial class q2 : Migration
    {
        protected override void Up(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.CreateTable(
                name: "submits",
                columns: table => new
                {
                    Id = table.Column<int>(nullable: false)
                        .Annotation("SqlServer:Identity", "1, 1"),
                    countrydetailsId = table.Column<int>(nullable: true),
                    statedetailsId = table.Column<int>(nullable: true),
                    citydetailsId = table.Column<int>(nullable: true)
                },
                constraints: table =>
                {
                    table.PrimaryKey("PK_submits", x => x.Id);
                    table.ForeignKey(
                        name: "FK_submits_Cities_citydetailsId",
                        column: x => x.citydetailsId,
                        principalTable: "Cities",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_submits_Countries_countrydetailsId",
                        column: x => x.countrydetailsId,
                        principalTable: "Countries",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                    table.ForeignKey(
                        name: "FK_submits_States_statedetailsId",
                        column: x => x.statedetailsId,
                        principalTable: "States",
                        principalColumn: "Id",
                        onDelete: ReferentialAction.Restrict);
                });

            migrationBuilder.CreateIndex(
                name: "IX_submits_citydetailsId",
                table: "submits",
                column: "citydetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_submits_countrydetailsId",
                table: "submits",
                column: "countrydetailsId");

            migrationBuilder.CreateIndex(
                name: "IX_submits_statedetailsId",
                table: "submits",
                column: "statedetailsId");
        }

        protected override void Down(MigrationBuilder migrationBuilder)
        {
            migrationBuilder.DropTable(
                name: "submits");
        }
    }
}
