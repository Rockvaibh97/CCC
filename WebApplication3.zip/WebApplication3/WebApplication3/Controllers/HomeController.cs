﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using System;
using System.Collections.Generic;
using System.Diagnostics;
using System.Linq;
using System.Threading.Tasks;
using WebApplication3.Models;

namespace WebApplication3.Controllers
{
    public class HomeController : Controller
    {
        private readonly ILogger<HomeController> _logger;
        private readonly ApplicationDbContext dbContext;

        public HomeController(ILogger<HomeController> logger, ApplicationDbContext dbContext)
        {
            _logger = logger;
            this.dbContext = dbContext;
        }



        public IActionResult Privacy()
        {
            return View();
        }

        [ResponseCache(Duration = 0, Location = ResponseCacheLocation.None, NoStore = true)]
        public IActionResult Error()
        {
            return View(new ErrorViewModel { RequestId = Activity.Current?.Id ?? HttpContext.TraceIdentifier });
        }
        public IActionResult GetCountries()
        {
            var countries = dbContext.Countries.ToList();
            return Json(countries);
        }
        public IActionResult GetStates(int id)
        {
            var states = dbContext.States.Where(e => e.Country.Id == id);
            return Json(states);
        }
        public IActionResult GetCities(int id)
        {
            var cities = dbContext.Cities.Where(e => e.State.Id == id);
            return Json(cities);
        }
        public IActionResult Index()
        {
            return View();
        }
        public IActionResult Delete(int id)
        {
            Submit submit = dbContext.submits.Find(id);            
            dbContext.submits.Remove(submit);
            dbContext.SaveChanges();
            return RedirectToAction("Show");           
        }
        [HttpPost]
        public IActionResult Index(Submit submit)
        {
            var getc = dbContext.Countries.FirstOrDefault(x => x.Id == submit.countrydetails.Id);
            var gets = dbContext.States.FirstOrDefault(x => x.Id == submit.statedetails.Id);
            var getci = dbContext.Cities.FirstOrDefault(x => x.Id == submit.citydetails.Id);
            Submit ss = new Submit();
            {
                ss.countrydetails = getc;
                ss.statedetails = gets;
                ss.citydetails = getci;
            };
            dbContext.submits.Add(ss);
            dbContext.SaveChanges();
            return RedirectToAction("Show");
        }
        public IActionResult Show()
        
        {
            var multipletable = (from S in dbContext.submits
                                 join C in dbContext.Countries on S.countrydetails.Id equals C.Id
                                 join St in dbContext.States on S.statedetails.Id equals St.Id
                                 join Ct in dbContext.Cities on S.citydetails.Id equals Ct.Id
                                 select new Submit
                                 {
                                     Id = S.Id,
                                     countrydetails = C,
                                     statedetails = St,
                                     citydetails = Ct
                                 }).ToList();
            return View(multipletable);

        }             
    }

 }



