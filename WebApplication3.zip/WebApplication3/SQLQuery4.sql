﻿insert into Countries(name)values
('India'),
('USA'),
('Japan'),
('Russia');
insert into States(name,CountryId)values
('Uttar Pradesh',1),
('Madhya Pradesh',1),
('Bihar',1),
('California',2),
('New York',2),
('Tokyo',3),
('Hiroshima',3),
('Nagasaki',3),
('Russia State',4);

insert into Cities(Name,StateId)values
('Varanasi',1),
('Prayagraj',1),
('Lucknow',1),
('Chatarpur',2),
('Malad',3);
select*from cities