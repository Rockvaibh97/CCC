﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Login_OTP.Utils.Enums
{
    public enum VerifyResetPasswordEnum
    {
        OTPEXPRIED,
        OTPVERIFIED,
        INVALIDOTP

    }
}
