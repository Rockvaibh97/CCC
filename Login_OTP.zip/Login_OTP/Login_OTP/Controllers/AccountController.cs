﻿using Login_OTP.Models;
using Login_OTP.Models.ViewModel;
using Login_OTP.Repository.Contract;
using Login_OTP.Utils.Enums;
using Microsoft.AspNetCore.Authentication;
using Microsoft.AspNetCore.Authentication.Cookies;
using Microsoft.AspNetCore.Authorization;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Identity;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Hosting;
using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Security.Claims;
using System.Threading.Tasks;

namespace Login_OTP.Controllers
{
    public class AccountController : Controller
    {
        private IUser userService;

        public AccountController(IUser user)
        {
            userService = user;
        }

        public IActionResult Login()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Login(SignIn model)
        {
            if (ModelState.IsValid)
            {
                var result = userService.AuthenticateUser(model);
                if (result == AuthoEnum.SUCCESS)
                {
                    //Create the identity for the user  
                    var identity = new ClaimsIdentity(new[] {
                    new Claim(ClaimTypes.Name, model.Email)
                }, CookieAuthenticationDefaults.AuthenticationScheme);

                    var principal = new ClaimsPrincipal(identity);

                    var login = HttpContext.SignInAsync(CookieAuthenticationDefaults.AuthenticationScheme, principal);
                    return RedirectToAction("Index", "Home");
                }
                else if (result == AuthoEnum.FAILED)
                {
                    ModelState.AddModelError(string.Empty, "Invalid login credentails !");
                    return View();
                }
                else if (result == AuthoEnum.NOTVERIFIED)
                {
                    ModelState.AddModelError(string.Empty, "Your account is still not active, please verify your account !");
                    return View();
                }
                ModelState.AddModelError(string.Empty, "You are not a valid user !");
                return View();
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Please enter login details !");
                return View();
            }
        }
        public IActionResult Logout()
        {
            var login = HttpContext.SignOutAsync(CookieAuthenticationDefaults.AuthenticationScheme);
            return RedirectToAction("Login");
        }
        public IActionResult Register()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Register(SignUp model)
        {
            if (ModelState.IsValid)
            {
                var result = userService.Register(model);
                if (result != null)
                {
                    return RedirectToAction("VerifyUser");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Email Already exist !");
                    return View(model);
                }
            }

            return View(model);
        }
        public IActionResult VerifyUser()
        {
            return View();
        }

        [HttpPost]
        public IActionResult VerifyUser(string Otp)
        {
            if (Otp != null)
            {
                VerifyAccountEnum result = userService.VerifyAccount(Otp);
                if (result == VerifyAccountEnum.OTPVERIFIED)
                {

                    return RedirectToAction("Login");
                    
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid OTP !");
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Please enter OTP");
                return View();
            }
           
        }
        public IActionResult Index()
        {
            return View();
        }

        [HttpGet]
        public IActionResult ForgotPassword()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ForgotPassword(ForgotPasswordModel forgotPasswordmodel)
        {
            if (ModelState.IsValid)
            {
                var user = userService.ForgotPassword(forgotPasswordmodel);
                if (user != null)
                {
                    return RedirectToAction("ForgotPasswordConfirmation");
                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Please Enter Valid Email !");
                    return View(forgotPasswordmodel);
                }
            }
            return View(forgotPasswordmodel);
        }

        public IActionResult ForgotPasswordConfirmation()
        {
            return View();
        }
        public IActionResult VerifyResetPassword()
        {
            return View();
        }
        [HttpPost]
        public IActionResult VerifyResetPassword(string Otp)
        {
            var getotp = userService.VerifyResetPassword(Otp);
            string mymail = TempData["Email"].ToString();
            if (Otp != null)
            {
                VerifyResetPasswordEnum result = userService.VerifyResetPassword(Otp);
                if (result == VerifyResetPasswordEnum.OTPVERIFIED)
                {

                    return RedirectToAction("ResetPassword",new { mail = mymail });

                }
                else
                {
                    ModelState.AddModelError(string.Empty, "Invalid OTP !");
                    return View();
                }
            }
            else
            {
                ModelState.AddModelError(string.Empty, "Please enter OTP");
                return View();
            }

        }


        public IActionResult ResetPassword()
        {
            return View();
        }
        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult ResetPassword(ResetPasswordModel model)
        {

            if (ModelState.IsValid)
            {
                var user = userService.ResetPassword(model);
                if (user != null)
                {
                    return View("ResetPasswordConfirmation");
                }
                if (user == null)
                {
                    return View("ForgotPassword");
                }
                var resetPassResult = userService.ResetPassword(model);
                return View();

            }
            return RedirectToAction("ResetPasswordConfirmation");

        }
        public IActionResult ResetPasswordConfirmation()
        {
            return View();
        }
    }
}


