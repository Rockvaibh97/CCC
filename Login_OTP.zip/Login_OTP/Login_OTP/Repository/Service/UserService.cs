﻿using Login_OTP.Models;
using Login_OTP.Models.ViewModel;
using Login_OTP.Repository.Contract;
using Login_OTP.Utils.Enums;
using Microsoft.AspNetCore.Http;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Net.Mail;
using System.Threading.Tasks;

namespace Login_OTP.Repository.Service
{
    public class UserService : IUser
    {
        private ApplicationDbContext dbContext;
        public UserService(ApplicationDbContext dbContext)
        {
            this.dbContext = dbContext;
        }

        public AuthoEnum AuthenticateUser(SignIn model)
        {
            var user = dbContext.Users.SingleOrDefault(e => e.Email == model.Email && e.Password == model.Password);
            if (user == null)
            {
                return AuthoEnum.FAILED;
            }
            else
            {
                return AuthoEnum.SUCCESS;
            }
        }

        public ForgotPasswordModel ForgotPassword(ForgotPasswordModel model)
        {
            dbContext.Users.Where(e => e.Email == model.Email).Any();
            {
                var user = new Users()
                {
                    Email = model.Email,
                    
            };

                string Otp = GenerateOTP();
                SendMail(model.Email, Otp);

                var VRpass = new VerifyResetPassword()
                {
                    OTP = Otp,
                    Email = model.Email,
            
                };
                dbContext.VerifyResetPasswords.Add(VRpass);
                dbContext.SaveChanges();
                return model;
            }
            
        }
        public ForgotPasswordModel ForgotPasswordConfirmation()
        {
            throw new NotImplementedException();
        }

        public SignUp Register(SignUp model)
        {
            if (dbContext.Users.Any(e => e.Email == model.Email))
            {
                return null;
            }
            else
            {
                var user = new Users()
                {
                    Email = model.Email,
                    Password = model.Password,
                    FirstName = model.FirstName,
                    LastName = model.LastName,
                    IsVerified = false,
                    IsActive = true
                };
                dbContext.Users.Add(user);
                string Otp = GenerateOTP();
                SendMail(model.Email, Otp);

                var VAccount = new VerifyAccount()
                {
                    OTP = Otp,
                    UserEmail = model.Email,
                    SendTime = DateTime.Now,

                };
                dbContext.VerifyAccounts.Add(VAccount);
                dbContext.SaveChanges();
                return model;
            }
        }
        private void SendMail(string to, string Otp)
        {
            MailMessage mail = new MailMessage();
            mail.To.Add(to);
            mail.From = new MailAddress("cvilazia@gmail.com");
            mail.Subject = "Verify Your Account";
            string Body = $"Your OTP is <b> {Otp}</b>  <br/>thanks for choosing us.";
            mail.Body = Body;
            mail.IsBodyHtml = true;
            SmtpClient smtp = new SmtpClient();
            smtp.Host = "smtp.gmail.com";
            smtp.Port = 587;
            smtp.UseDefaultCredentials = false;
            smtp.Credentials = new NetworkCredential("cvilazia@gmail.com", "pa123456!@#"); // Enter seders User name and password  
            smtp.EnableSsl = true;
            smtp.Send(mail);
        }
        private string GenerateOTP()
        {
            var chars = "ABCDEFGHIJKLMNOPQRSTUVWXYZ0123456789";
            var random = new Random();
            var list = Enumerable.Repeat(0, 8).Select(x => chars[random.Next(chars.Length)]);
            var r = string.Join("", list);
            return r;
        }

        public ResetPasswordModel ResetPassword(ResetPasswordModel model)
        {
            
            var user = dbContext.Users.Where(c => c.Email == model.Email).FirstOrDefault();

            user.Password = model.Password;
             
                dbContext.Users.Update(user);
                dbContext.SaveChanges();
                return model;
            
        }

        public VerifyAccountEnum VerifyAccount(string Otp)
        {
            if (dbContext.VerifyAccounts.Any(e => e.OTP == Otp))
            {
                var Acc = dbContext.VerifyAccounts.SingleOrDefault(e => e.OTP == Otp);
                var User = dbContext.Users.SingleOrDefault(e => e.Email == Acc.UserEmail);
                dbContext.VerifyAccounts.Remove(Acc);
                dbContext.Users.Update(User);
                dbContext.SaveChanges();
                return VerifyAccountEnum.OTPVERIFIED;
            }
            else
            {
                return VerifyAccountEnum.INVALIDOTP;
            }
        }

        public VerifyResetPasswordEnum VerifyResetPassword(string Otp)
        {
            var findotp = dbContext.VerifyResetPasswords.OrderByDescending(x => x.Id).First();
            var a = from s in dbContext.VerifyResetPasswords orderby s.Id descending select s;
              
            if (dbContext.VerifyResetPasswords.Any(a => a.OTP == Otp))
            {
                var rrr = dbContext.VerifyResetPasswords.SingleOrDefault(a => a.OTP == findotp.OTP);
                var User = dbContext.Users.SingleOrDefault(e => e.Email == rrr.Email);
                dbContext.VerifyResetPasswords.Remove(rrr);
                dbContext.Users.Update(User);
                dbContext.SaveChanges();
                return VerifyResetPasswordEnum.OTPVERIFIED;
            }
            else
            {
                return VerifyResetPasswordEnum.INVALIDOTP;
            }
        }
    }
}