﻿using Login_OTP.Models;
using Login_OTP.Models.ViewModel;
using Login_OTP.Utils.Enums;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Login_OTP.Repository.Contract
{
    public interface IUser
    {
        SignUp Register(SignUp model);
        AuthoEnum AuthenticateUser(SignIn model);
        VerifyAccountEnum VerifyAccount(string Otp);
        VerifyResetPasswordEnum VerifyResetPassword(string Otp);
        ForgotPasswordModel ForgotPassword(ForgotPasswordModel model);
        ForgotPasswordModel ForgotPasswordConfirmation();
        ResetPasswordModel ResetPassword(ResetPasswordModel model);

       


    }
}
